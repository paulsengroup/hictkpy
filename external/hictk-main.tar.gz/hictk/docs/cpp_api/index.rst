..
   Copyright (C) 2023 Roberto Rossini <roberros@uio.no>
   SPDX-License-Identifier: MIT

C++ API Reference
#################

hictk C++ API is structured as follows:

.. toctree::
   :maxdepth: 1

   generic
   cooler
   hic
   shared
   transformers
