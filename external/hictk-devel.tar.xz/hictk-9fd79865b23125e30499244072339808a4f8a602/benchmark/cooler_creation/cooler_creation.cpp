// Copyright (C) 2024 Roberto Rossini <roberros@uio.no>
//
// SPDX-License-Identifier: MIT

#include <fmt/format.h>

#include <CLI/CLI.hpp>
#include <algorithm>
#include <chrono>
#include <cstddef>
#include <exception>
#include <filesystem>
#include <hictk/cooler/cooler.hpp>
#include <hictk/pixel.hpp>
#include <vector>

using namespace hictk;

struct Config {
  std::filesystem::path uri{};
  std::filesystem::path out_path{};
  std::size_t chunk_size{10'000'000};
  std::size_t iterations{1};
  bool validate{true};
};

using PixelBuffer = std::vector<Pixel<std::uint32_t>>;

[[nodiscard]] std::vector<PixelBuffer> chunk_pixels(const cooler::File &f, std::size_t chunk_size) {
  std::vector<PixelBuffer> buffer{};
  PixelBuffer chunk{};

  std::for_each(f.begin<std::uint32_t>(), f.end<std::uint32_t>(), [&](const auto &p) {
    if (chunk.size() == chunk_size) {
      buffer.push_back(chunk);
      chunk.clear();
    }
    chunk.push_back(Pixel<std::uint32_t>(f.bins(), p));
  });

  if (!chunk.empty()) {
    buffer.emplace_back(chunk);
  }

  return buffer;
}

// NOLINTNEXTLINE(bugprone-exception-escape)
int main(int argc, char **argv) noexcept {
  CLI::App cli{};
  Config config{};
  cli.add_option("in-uri", config.uri, "URI to an input cooler file.")->required();
  cli.add_option("out-path", config.out_path, "Path where to store the output cooler.")->required();
  cli.add_option("--chunk-size", config.chunk_size, "Chunk size.")->capture_default_str();
  cli.add_option("--iterations", config.iterations, "Number of iterations to perform.")
      ->capture_default_str();
  cli.add_flag("--validate,!--no-validate", config.validate, "Validate pixels before append.")
      ->capture_default_str();

  try {
    cli.parse(argc, argv);

    const cooler::File f(config.uri.string());
    const auto pixels = chunk_pixels(f, config.chunk_size);

    std::size_t num_pixels = 0;
    std::uint64_t elapsed_time = 0;
    for (std::size_t i = 0; i < config.iterations; ++i) {
      const auto t0 = std::chrono::system_clock::now();
      {
        auto writer =
            cooler::File::create(config.out_path.string(), f.chromosomes(), f.resolution());

        for (const auto &chunk : pixels) {
          writer.append_pixels(chunk.begin(), chunk.end(), config.validate);
          num_pixels += chunk.size();
        }
      }
      const auto t1 = std::chrono::system_clock::now();
      std::filesystem::remove(config.out_path);

      const auto delta = static_cast<std::uint64_t>(
          std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count());
      elapsed_time += delta;
    }

    const auto avg_time =
        (static_cast<double>(elapsed_time) / static_cast<double>(config.iterations)) / 1.0e9;
    const auto throughput = static_cast<double>(num_pixels) / avg_time;

    fmt::print(FMT_STRING("hictk::cooler::File::create throughput: {:.4} pixels/s\n"), throughput);

  } catch (const CLI::ParseError &e) {
    return cli.exit(e);
  } catch (const std::exception &e) {
    assert(cli);
    fmt::print(stderr, FMT_STRING("FAILURE! {} encountered the following error: {}.\n"), argv[0],
               e.what());
    return 1;
  } catch (...) {
    fmt::print(stderr,
               FMT_STRING("FAILURE! {} encountered the following error: Caught an "
                          "unhandled exception!\n"),
               argv[0]);
    return 1;
  }
  return 0;
}
